#include "map.h"
#include "Maze.h"

//creates a map with a randomly generated maze of walls and air
//assigns the clients to each player
//creates a ghost
Map::Map(sf::TcpSocket *client1, sf::TcpSocket *client2)
{
	Maze maze;
	maze.generateMaze();
	int** ptr = maze.copyMazeToIntArray();

  //populates the map with walls
  for (int i = 0; i < WIDTH-1; ++i)
    for (int j = 0; j < HEIGHT -1; ++j)
      map[i][j] = ptr[i][j] == 0 ? WALL : AIR;

  for (int i = 0; i < WIDTH; ++i)
    map[i][HEIGHT - 1] = WALL;
  for (int i = 0; i < HEIGHT; ++i)
    map[WIDTH - 1][i] = WALL;

  //you can uncomment the code below if you want to try a random grid
  /*for (int i = 0; i < WIDTH-1; ++i)
    for (int j = 0; j < HEIGHT -1; ++j)
      map[i][j] = rand() % 15 == 0 ? WALL : AIR;*/

  p1 = new Player(sf::Vector2f(190, 190), client1);
  p2 = new Player(sf::Vector2f(190, 190), client2);
  ghost = new Ghosts();
}
//updates the game object's positions evert cycle
int Map::update()
{
  int i = ghost->update(p1->getPos(), p2->getPos());
  //std::cout << i << std::endl;
  //returns 1 if either client closes the connection
  if (p1->update(map) || p2->update(map))
    return 1;
  //returns if player 1 or 2 wins
  if (i)
    return i + 1;
  return 0;
}
//dislays all of the elements in the map (client side)
void Map::displayMap(sf::RenderWindow &window)
{
  //displays the walls
  sf::RectangleShape wall(sf::Vector2f(10, 10));
  wall.setFillColor(sf::Color::Blue);
  for (int i = 0; i < WIDTH; ++i)
    for (int j = 0; j < HEIGHT; ++j)
      if (map[i][j] == WALL)
      {
        wall.setPosition(i * 10, j * 10);
	window.draw(wall);
      }
  
  //displays the ghost
  sf::RectangleShape ghosts(sf::Vector2f(20, 20));
  ghosts.setFillColor(sf::Color::Red);
  ghosts.setPosition(ghost->getPos());
  window.draw(ghosts);

  //displays both players
  sf::RectangleShape player(sf::Vector2f(10, 10));
  player.setFillColor(sf::Color::White);

  player.setPosition(p1->getPos());
  window.draw(player);

  player.setPosition(p2->getPos());
  window.draw(player);
}
//packages the server side map into a char array which is sent to both clients in the main()
void Map::sendMap(char dataOut[3000])
{
  //sends the walls
  for (int i = 0; i < WIDTH; ++i)
    for (int j = 0; j < HEIGHT; ++j)
      dataOut[i * 40 + j] = (char) map[i][j];

  //after the walls are sent, packages the positions and sends them in the same array
  int *index = (int *) (dataOut + 1600);
  *(index + 0) = p1->getPos().x;
  *(index + 1) = p1->getPos().y;
  *(index + 2) = p2->getPos().x;
  *(index + 3) = p2->getPos().y;
  *(index + 4) = ghost->getPos().x;
  *(index + 5) = ghost->getPos().y;
}
//takes the char array that was sent to the client and turns it into a map to display (no server side work)
void Map::extractMap(char dataIn[3000])
{
  //populates the walls
  for (int i = 0; i < WIDTH; ++i)
    for (int j = 0; j < HEIGHT; ++j)
      map[i][j] = (int) dataIn[i * 40 + j];
  
  //gets the position of the ghost and the players
  int *index = (int *) (dataIn + 1600);
  p1->setPos(*(index + 0), *(index + 1));
  p2->setPos(*(index + 2), *(index + 3));
  ghost->setPos(*(index+4), *(index + 5));
}
