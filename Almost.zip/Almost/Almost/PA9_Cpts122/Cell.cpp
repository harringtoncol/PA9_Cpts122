#include "Cell.h"

void Cell::print()
{
	//std::cout << position.x << "," << position.y << std::endl;
}
